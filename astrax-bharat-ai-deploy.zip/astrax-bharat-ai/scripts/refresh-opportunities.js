const fs = require('fs');
const path = require('path');

loadEnvFile(path.join(__dirname, '..', '.env'));

const DATA_DIR = path.join(__dirname, '..', 'data');
const OUTPUT = path.join(DATA_DIR, 'generated-opportunities.json');

async function main() {
  const seed = readJson(path.join(DATA_DIR, 'opportunities.json'), []);
  if (!process.env.ASTRA_SERPER_API_KEY) {
    console.log('ASTRA_SERPER_API_KEY not found. Writing seed opportunities only.');
    fs.writeFileSync(OUTPUT, JSON.stringify(seed, null, 2));
    return;
  }

  const queries = [
    'site:scholarships.gov.in India student scholarship official',
    'site:careers.google.com students internships official',
    'India student fellowship opportunity official'
  ];

  const results = [];
  for (const query of queries) {
    const items = await searchWithSerper(query);
    items.forEach((item) => {
      results.push({
        title: item.title,
        link: item.url,
        source: 'Serper refresh',
        category: 'Opportunity',
        date: new Date().toLocaleDateString('en-IN'),
        summary: item.snippet
      });
    });
  }

  const merged = dedupeBy([...seed, ...results], (item) => `${item.title}|${item.link}`).slice(0, 25);
  fs.writeFileSync(OUTPUT, JSON.stringify(merged, null, 2));
  console.log(`Wrote ${merged.length} opportunities to ${OUTPUT}`);
}

async function searchWithSerper(query) {
  const response = await fetch('https://google.serper.dev/search', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-KEY': process.env.ASTRA_SERPER_API_KEY
    },
    body: JSON.stringify({ q: query, gl: 'in', hl: 'en', num: 8 })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Serper error ${response.status}: ${errorText}`);
  }

  const data = await response.json();
  return (Array.isArray(data.organic) ? data.organic : []).map((item) => ({
    title: item.title || 'Result',
    url: item.link || '#',
    snippet: item.snippet || ''
  }));
}

function loadEnvFile(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    raw.split(/\r?\n/).forEach((line) => {
      if (!line || /^\s*#/.test(line)) return;
      const match = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*)\s*$/);
      if (!match) return;
      const key = match[1];
      let value = match[2];
      value = value.replace(/^['"]|['"]$/g, '');
      if (!(key in process.env)) process.env[key] = value;
    });
  } catch {
    // ignore missing .env
  }
}

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function dedupeBy(list, keyFn) {
  const seen = new Set();
  return list.filter((item) => {
    const key = keyFn(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
