const LANGUAGES = [
  { code: 'en-IN', label: 'English' },
  { code: 'hi-IN', label: 'हिन्दी' },
  { code: 'as-IN', label: 'অসমীয়া' },
  { code: 'bn-IN', label: 'বাংলা' },
  { code: 'brx-IN', label: 'बड़ो' },
  { code: 'doi-IN', label: 'डोगरी' },
  { code: 'gu-IN', label: 'ગુજરાતી' },
  { code: 'kn-IN', label: 'ಕನ್ನಡ' },
  { code: 'ks-IN', label: 'कॉशुर / کٲشُر' },
  { code: 'kok-IN', label: 'कोंकणी' },
  { code: 'mai-IN', label: 'मैथिली' },
  { code: 'ml-IN', label: 'മലയാളം' },
  { code: 'mni-IN', label: 'Meitei / মৈতৈলোন' },
  { code: 'mr-IN', label: 'मराठी' },
  { code: 'ne-IN', label: 'नेपाली' },
  { code: 'or-IN', label: 'ଓଡ଼ିଆ' },
  { code: 'pa-IN', label: 'ਪੰਜਾਬੀ' },
  { code: 'sa-IN', label: 'संस्कृतम्' },
  { code: 'sat-IN', label: 'ᱥᱟᱱᱛᱟᱲᱤ' },
  { code: 'sd-IN', label: 'سنڌي / सिंधी' },
  { code: 'ta-IN', label: 'தமிழ்' },
  { code: 'te-IN', label: 'తెలుగు' },
  { code: 'ur-IN', label: 'اردو' },
  { code: 'hinglish', label: 'Hinglish' }
];

const ASSISTANT_MODES = [
  { code: 'general', label: 'General AI' },
  { code: 'study', label: 'Study Coach' },
  { code: 'builder', label: 'No-Code Builder' },
  { code: 'creator', label: 'Creator / Pinterest' },
  { code: 'launcher', label: 'Phone Launcher' },
  { code: 'calm', label: 'Calm Support' }
];

const VOICE_PRESETS = [
  { name: 'Anaya', type: 'Girl', region: 'Delhi', tone: 'Warm Mentor' },
  { name: 'Isha', type: 'Girl', region: 'Mumbai', tone: 'Confident' },
  { name: 'Meera', type: 'Girl', region: 'Jaipur', tone: 'Calm Guide' },
  { name: 'Kavya', type: 'Girl', region: 'Bengaluru', tone: 'Tech Friendly' },
  { name: 'Tara', type: 'Girl', region: 'Kolkata', tone: 'Elegant' },
  { name: 'Saanvi', type: 'Girl', region: 'Lucknow', tone: 'Empathetic' },
  { name: 'Aditi', type: 'Girl', region: 'Pune', tone: 'Youthful' },
  { name: 'Naina', type: 'Girl', region: 'Chandigarh', tone: 'Professional' },
  { name: 'Zoya', type: 'Girl', region: 'Hyderabad', tone: 'Soft Spoken' },
  { name: 'Diya', type: 'Girl', region: 'Ahmedabad', tone: 'Bright' },
  { name: 'Aarav', type: 'Boy', region: 'Delhi', tone: 'Commanding' },
  { name: 'Vihaan', type: 'Boy', region: 'Mumbai', tone: 'Friendly' },
  { name: 'Arjun', type: 'Boy', region: 'Indore', tone: 'Focused' },
  { name: 'Kabir', type: 'Boy', region: 'Bengaluru', tone: 'Calm' },
  { name: 'Reyansh', type: 'Boy', region: 'Patna', tone: 'Learner-first' },
  { name: 'Dhruv', type: 'Boy', region: 'Noida', tone: 'Strategic' },
  { name: 'Aditya', type: 'Boy', region: 'Pune', tone: 'Sharp' },
  { name: 'Krishna', type: 'Boy', region: 'Varanasi', tone: 'Wise' },
  { name: 'Imran', type: 'Boy', region: 'Hyderabad', tone: 'Smooth' },
  { name: 'Veer', type: 'Boy', region: 'Surat', tone: 'Energetic' }
];

const DEFAULT_RESOURCES = {
  CUET: [
    { title: 'NCERT official site', link: 'https://ncert.nic.in/' },
    { title: 'CUET / NTA official portal', link: 'https://exams.nta.ac.in/CUET-UG/' }
  ],
  NEET: [
    { title: 'NTA NEET official portal', link: 'https://neet.nta.nic.in/' },
    { title: 'NCERT Biology / Science', link: 'https://ncert.nic.in/' }
  ],
  JEE: [
    { title: 'JEE Main official portal', link: 'https://jeemain.nta.nic.in/' },
    { title: 'NTA official portal', link: 'https://nta.ac.in/' }
  ],
  NDA: [
    { title: 'UPSC NDA official portal', link: 'https://upsc.gov.in/' },
    { title: 'Join Indian Army overview', link: 'https://joinindianarmy.nic.in/' }
  ],
  UPSC: [
    { title: 'UPSC official portal', link: 'https://upsc.gov.in/' },
    { title: 'PIB official updates', link: 'https://pib.gov.in/' }
  ]
};

const DEFAULT_OPPORTUNITIES = [
  {
    title: 'National Scholarship Portal',
    link: 'https://scholarships.gov.in/',
    source: 'Government of India',
    category: 'Scholarship',
    date: 'Daily check'
  },
  {
    title: 'Google Student Programs',
    link: 'https://careers.google.com/students/',
    source: 'Google',
    category: 'Opportunity',
    date: 'Rolling'
  },
  {
    title: 'AICTE official opportunities',
    link: 'https://www.aicte-india.org/',
    source: 'AICTE',
    category: 'Internship',
    date: 'Official updates'
  }
];

const PUBLIC_APP_URL = 'https://jarvis-app.railway.app';
const PUBLIC_QR_IMAGE = 'qr/jarvis-app-railway-permanent-qr.png';

const DEFAULT_SETTINGS = {
  backendUrl: '',
  useBackendProxy: true,
  aiBaseUrl: 'https://openrouter.ai/api/v1',
  aiModel: 'openai/gpt-4.1-mini',
  aiApiKey: '',
  searchEndpoint: '',
  searchApiKey: '',
  imageEndpoint: '',
  ttsEndpoint: '',
  firebaseApiKey: '',
  firebaseAuthDomain: '',
  firebaseProjectId: '',
  firebaseAppId: '',
  firebaseStorageBucket: '',
  firebaseMessagingSenderId: '',
  notes: ''
};

const state = {
  language: localStorage.getItem('astrax_language') || 'en-IN',
  mode: localStorage.getItem('astrax_mode') || 'general',
  psychologyAware: safeJSON('astrax_psychology', true),
  resources: safeJSON('astrax_resources', DEFAULT_RESOURCES),
  opportunities: safeJSON('astrax_opportunities', DEFAULT_OPPORTUNITIES),
  settings: { ...DEFAULT_SETTINGS, ...safeJSON('astrax_settings', DEFAULT_SETTINGS) },
  generatedAppHtml: '',
  installPromptEvent: null,
  currentImage: null,
  imageExtras: { sepia: 0, hue: 0, blur: 0 },
  chatHistory: [],
  latestSources: []
};

const firebaseState = {
  initialized: false,
  initializing: false,
  app: null,
  auth: null,
  db: null,
  user: null,
  modules: null,
  configKey: ''
};

const el = {};
let recognition = null;

document.addEventListener('DOMContentLoaded', init);

async function init() {
  mapElements();
  populateLanguages();
  populateModes();
  renderStudyTags();
  loadSettingsIntoForm();
  bindEvents();
  seedChat();
  drawCanvasPlaceholder();
  updateLanguageUI();
  autoFillQrWithCurrentUrl();
  registerServiceWorker();
  setupSpeechRecognition();
  await maybeInitFirebase();
  await Promise.all([refreshResourcesFromBackend(), refreshOpportunitiesFromBackend(false)]);
  renderResources();
  renderOpportunities();
  renderVoiceGrid();
  updateAuthUi();
}

function mapElements() {
  [
    'languageSelect', 'assistantModeSelect', 'assistantLanguageLabel', 'languageHint', 'webSearchToggle',
    'psychologyToggle', 'authStatus', 'authBtn', 'chatMessages', 'sourcePanel', 'sourceList',
    'clearSourcesBtn', 'promptInput', 'voiceStatus', 'voiceInputBtn', 'clearChatBtn', 'sendBtn',
    'studyTags', 'refreshResourcesBtn', 'examSelect', 'resourceTitle', 'resourceLink', 'addResourceBtn',
    'resourceList', 'appIdeaInput', 'generateAppBtn', 'downloadAppBtn', 'copyAppBtn',
    'generatedAppPreview', 'imageUpload', 'imagePrompt', 'applyPromptStyleBtn', 'downloadImageBtn',
    'brightnessSlider', 'contrastSlider', 'saturationSlider', 'imageCanvas', 'pinTopic', 'pinAudience',
    'pinVibe', 'pinCTA', 'generatePinBtn', 'pinResult', 'voiceGrid', 'opportunityMeta',
    'refreshOpportunityBtn', 'opportunityTitle', 'opportunityLink', 'addOpportunityBtn',
    'opportunityList', 'cameraInput', 'deployUrl', 'generateQrBtn', 'downloadGuideBtn', 'qrImage',
    'publishGuide', 'settingsDrawer', 'settingsBtn', 'closeSettingsBtn', 'saveSettingsBtn',
    'resetSettingsBtn', 'installBtn', 'shareBtn', 'backendUrl', 'useBackendProxy', 'aiBaseUrl',
    'aiModel', 'aiApiKey', 'searchEndpoint', 'searchApiKey', 'imageEndpoint', 'ttsEndpoint',
    'firebaseApiKey', 'firebaseAuthDomain', 'firebaseProjectId', 'firebaseAppId', 'firebaseStorageBucket',
    'firebaseMessagingSenderId', 'settingsNotes', 'authDrawer', 'closeAuthBtn', 'firebaseStatus',
    'authName', 'authEmail', 'authPassword', 'authRole', 'signupBtn', 'loginBtn', 'logoutBtn'
  ].forEach((id) => {
    el[id] = document.getElementById(id);
  });
}

function bindEvents() {
  el.languageSelect.addEventListener('change', () => {
    state.language = el.languageSelect.value;
    localStorage.setItem('astrax_language', state.language);
    updateLanguageUI();
  });

  el.assistantModeSelect.addEventListener('change', () => {
    state.mode = el.assistantModeSelect.value;
    localStorage.setItem('astrax_mode', state.mode);
    updateLanguageUI();
  });

  el.psychologyToggle.checked = state.psychologyAware;
  el.psychologyToggle.addEventListener('change', () => {
    state.psychologyAware = el.psychologyToggle.checked;
    localStorage.setItem('astrax_psychology', JSON.stringify(state.psychologyAware));
  });

  el.sendBtn.addEventListener('click', handleSend);
  el.promptInput.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') handleSend();
  });

  el.clearChatBtn.addEventListener('click', clearChat);
  el.clearSourcesBtn.addEventListener('click', clearSources);
  el.voiceInputBtn.addEventListener('click', toggleSpeechRecognition);

  el.refreshResourcesBtn.addEventListener('click', async () => {
    await refreshResourcesFromBackend();
    renderResources();
    addMessage('assistant', 'Study resources refreshed with official/legal starter links.');
  });

  el.addResourceBtn.addEventListener('click', addResource);
  el.generateAppBtn.addEventListener('click', generateStarterApp);
  el.downloadAppBtn.addEventListener('click', downloadGeneratedApp);
  el.copyAppBtn.addEventListener('click', copyGeneratedApp);
  el.generatePinBtn.addEventListener('click', generatePinterestCopy);
  el.applyPromptStyleBtn.addEventListener('click', applyPromptStyle);
  el.downloadImageBtn.addEventListener('click', downloadCanvasImage);
  el.imageUpload.addEventListener('change', handleImageUpload);
  el.brightnessSlider.addEventListener('input', redrawCanvas);
  el.contrastSlider.addEventListener('input', redrawCanvas);
  el.saturationSlider.addEventListener('input', redrawCanvas);

  el.refreshOpportunityBtn.addEventListener('click', async () => {
    await refreshOpportunitiesFromBackend(true);
    renderOpportunities();
  });
  el.addOpportunityBtn.addEventListener('click', addOpportunity);

  el.generateQrBtn.addEventListener('click', generateQr);
  el.downloadGuideBtn.addEventListener('click', downloadDeployGuide);

  document.querySelectorAll('.action-btn').forEach((button) => {
    button.addEventListener('click', () => runQuickAction(button.dataset.action));
  });

  el.settingsBtn.addEventListener('click', () => el.settingsDrawer.classList.remove('hidden'));
  el.closeSettingsBtn.addEventListener('click', () => el.settingsDrawer.classList.add('hidden'));
  el.settingsDrawer.addEventListener('click', (event) => {
    if (event.target === el.settingsDrawer) el.settingsDrawer.classList.add('hidden');
  });

  el.authBtn.addEventListener('click', openAuthDrawer);
  el.closeAuthBtn.addEventListener('click', closeAuthDrawer);
  el.authDrawer.addEventListener('click', (event) => {
    if (event.target === el.authDrawer) closeAuthDrawer();
  });
  el.signupBtn.addEventListener('click', handleSignup);
  el.loginBtn.addEventListener('click', handleLogin);
  el.logoutBtn.addEventListener('click', handleLogout);

  el.saveSettingsBtn.addEventListener('click', saveSettings);
  el.resetSettingsBtn.addEventListener('click', resetSettings);
  el.installBtn.addEventListener('click', installPwa);
  el.shareBtn.addEventListener('click', shareApp);

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    state.installPromptEvent = event;
    el.installBtn.textContent = 'Install Ready';
  });

  window.speechSynthesis?.addEventListener?.('voiceschanged', renderVoiceGrid);
}

function seedChat() {
  addMessage(
    'assistant',
    'Namaste! I am AstraX Bharat AI. This upgraded build includes a PWA frontend, Node backend starter, OpenRouter-ready AI, Serper-ready search, Firebase-ready auth, study tools, creator tools, and Android-ready docs.\n\nTo unlock full live power, add your provider keys in Settings or backend env files.'
  );
}

function clearChat() {
  el.chatMessages.innerHTML = '';
  state.chatHistory = [];
  clearSources();
  seedChat();
}

function clearSources() {
  state.latestSources = [];
  el.sourceList.innerHTML = '';
  el.sourcePanel.classList.add('hidden');
}

function populateLanguages() {
  el.languageSelect.innerHTML = LANGUAGES.map((lang) => `<option value="${lang.code}">${lang.label}</option>`).join('');
  el.languageSelect.value = state.language;
}

function populateModes() {
  el.assistantModeSelect.innerHTML = ASSISTANT_MODES.map((mode) => `<option value="${mode.code}">${mode.label}</option>`).join('');
  el.assistantModeSelect.value = state.mode;
}

function updateLanguageUI() {
  const current = LANGUAGES.find((lang) => lang.code === state.language) || LANGUAGES[0];
  const mode = ASSISTANT_MODES.find((item) => item.code === state.mode)?.label || 'General AI';
  el.assistantLanguageLabel.textContent = `Language: ${current.label}`;
  el.languageHint.textContent = `Selected reply language: ${current.label}. Active mode: ${mode}. Connect OpenRouter, Serper, and Firebase for fully live features.`;
}

function addMessage(role, text) {
  const template = document.getElementById('messageTemplate');
  const node = template.content.firstElementChild.cloneNode(true);
  node.classList.add(role === 'user' ? 'user' : 'assistant');
  node.querySelector('.message-avatar').textContent = role === 'user' ? 'YOU' : 'AX';
  node.querySelector('.message-bubble').textContent = text;
  el.chatMessages.appendChild(node);
  el.chatMessages.scrollTop = el.chatMessages.scrollHeight;

  state.chatHistory.push({ role: role === 'user' ? 'user' : 'assistant', content: text });
  if (state.chatHistory.length > 14) state.chatHistory = state.chatHistory.slice(-14);
  persistChatSnippet(role, text);
}

async function handleSend() {
  const text = el.promptInput.value.trim();
  if (!text) return;

  addMessage('user', text);
  el.promptInput.value = '';

  if (handleLocalCommand(text)) return;

  addMessage('assistant', 'Processing...');
  const placeholder = el.chatMessages.lastElementChild;

  try {
    const result = await getAssistantReply(text);
    placeholder.querySelector('.message-bubble').textContent = result.reply;
    state.chatHistory[state.chatHistory.length - 1].content = result.reply;
    showSources(result.sources || []);
    persistChatSnippet('assistant', result.reply);
  } catch (error) {
    placeholder.querySelector('.message-bubble').textContent = `Sorry, something failed. ${error.message}`;
    showSources([]);
  }

  el.chatMessages.scrollTop = el.chatMessages.scrollHeight;
}

function handleLocalCommand(text) {
  const lower = text.toLowerCase();
  const actions = [
    ['open whatsapp', 'whatsapp'],
    ['open mail', 'mail'],
    ['open gmail', 'mail'],
    ['open maps', 'maps'],
    ['open youtube', 'youtube'],
    ['open calendar', 'calendar'],
    ['open play store', 'playstore'],
    ['open camera', 'camera'],
    ['call', 'call']
  ];

  for (const [keyword, action] of actions) {
    if (lower.includes(keyword)) {
      runQuickAction(action);
      addMessage('assistant', `Quick action triggered: ${action}. On supported devices, the related app or intent should open.`);
      return true;
    }
  }

  if (lower.includes('generate pinterest')) {
    generatePinterestCopy();
    addMessage('assistant', 'Pinterest copy is ready in the creator panel below.');
    return true;
  }

  if (lower.includes('build') && lower.includes('app')) {
    el.appIdeaInput.value = text;
    generateStarterApp();
    addMessage('assistant', 'Starter app HTML generated below. You can copy or download it.');
    return true;
  }

  return false;
}

async function getAssistantReply(text) {
  if (state.settings.useBackendProxy) {
    try {
      return await askBackend(text);
    } catch (error) {
      return askDirectApiOrOffline(text, error.message);
    }
  }
  return askDirectApiOrOffline(text);
}

async function askBackend(text) {
  const url = `${normalizeBaseUrl(state.settings.backendUrl)}/api/chat`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: text,
      history: state.chatHistory.slice(-10),
      language: state.language,
      mode: state.mode,
      psychologyAware: state.psychologyAware,
      useWebSearch: el.webSearchToggle.checked
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Backend error ${response.status}: ${errorText.slice(0, 180)}`);
  }

  const data = await response.json();
  return { reply: data.reply || 'No reply returned by backend.', sources: Array.isArray(data.sources) ? data.sources : [] };
}

async function askDirectApiOrOffline(text, backendError = '') {
  const hasRemote = state.settings.aiBaseUrl && state.settings.aiModel && state.settings.aiApiKey;
  if (hasRemote) {
    try {
      const reply = await askDirectModel(text);
      return { reply, sources: [] };
    } catch (error) {
      return {
        reply: `${generateOfflineReply(text)}\n\n(Direct model failed${backendError ? ` after backend issue: ${backendError}` : ''}. Error: ${error.message})`,
        sources: []
      };
    }
  }

  return {
    reply: `${generateOfflineReply(text)}${backendError ? `\n\n(Backend not available: ${backendError})` : ''}`,
    sources: []
  };
}

async function askDirectModel(text) {
  const endpoint = normalizeChatEndpoint(state.settings.aiBaseUrl);
  let searchContext = '';
  if (el.webSearchToggle.checked && state.settings.searchEndpoint) {
    searchContext = await fetchSearchContext(text);
  }

  const currentLang = LANGUAGES.find((lang) => lang.code === state.language)?.label || 'English';
  const modeLabel = ASSISTANT_MODES.find((mode) => mode.code === state.mode)?.label || 'General AI';
  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${state.settings.aiApiKey}`
  };

  if (endpoint.includes('openrouter.ai')) {
    headers['HTTP-Referer'] = location.origin || 'https://example.com';
    headers['X-Title'] = 'AstraX Bharat AI';
  }

  const payload = {
    model: state.settings.aiModel,
    temperature: 0.45,
    messages: [
      {
        role: 'system',
        content: `You are AstraX Bharat AI, a polished India-first assistant. Reply in ${currentLang} unless user asks otherwise. Active mode: ${modeLabel}. Be practical, clear, safe, and refuse illegal or pirated requests. ${state.psychologyAware ? 'Be empathetic and psychologically aware without pretending to be a doctor.' : ''}`
      },
      ...(searchContext ? [{ role: 'system', content: `Web research context:\n${searchContext}` }] : []),
      ...state.chatHistory.slice(-8),
      { role: 'user', content: text }
    ]
  };

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Model API error ${response.status}: ${errorText.slice(0, 220)}`);
  }

  const data = await response.json();
  return data?.choices?.[0]?.message?.content || data?.output_text || data?.response || 'No response body received.';
}

function generateOfflineReply(text) {
  const lower = text.toLowerCase();
  const currentLang = LANGUAGES.find((lang) => lang.code === state.language)?.label || 'English';
  const empathyWords = ['sad', 'stress', 'stressed', 'anxious', 'depressed', 'tired', 'lonely', 'confused', 'worried', 'burnout'];
  const examWords = ['cuet', 'neet', 'jee', 'nda', 'upsc'];

  if (state.psychologyAware && empathyWords.some((word) => lower.includes(word))) {
    return `I noticed emotional pressure in your message. Start with one calm step: breathe slowly, drink water, and tell me whether you want comfort, strategy, or a task plan. I can help in ${currentLang}.`;
  }
  if (examWords.some((word) => lower.includes(word))) {
    return `I can help with ${text.toUpperCase().includes('UPSC') ? 'UPSC' : 'competitive exam'} planning: revision map, daily routine, mock strategy, and topic tracking. The Study Hub contains official/legal starter links.`;
  }
  if (lower.includes('scholarship') || lower.includes('opportunity')) {
    return 'Use the opportunity feed to track scholarships, Google programs, internships, fellowships, and student opportunities. Refresh will use backend feeds if configured.';
  }
  if (lower.includes('photo') || lower.includes('image')) {
    return 'Use Image Studio to upload a photo, apply prompt-style edits, fine-tune sliders, and download the result. For true AI editing, connect an image API.';
  }
  if (lower.includes('mod apk') || lower.includes('premium version') || lower.includes('crack')) {
    return 'I can’t help create cracked apps, mod APKs, or bypass paid features. I can help find legal alternatives, student discounts, or official links.';
  }
  return `Offline prototype response:\n\nI can help structure your request, generate starter app code, organize study workflows, and guide setup for OpenRouter, Serper, Firebase, and Android packaging. Current language: ${currentLang}.`;
}

async function fetchSearchContext(query) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.settings.searchApiKey) headers.Authorization = `Bearer ${state.settings.searchApiKey}`;
  const response = await fetch(state.settings.searchEndpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify({ query })
  });
  if (!response.ok) throw new Error(`Search API error ${response.status}`);
  const data = await response.json();
  return formatSearchPayload(data);
}

function formatSearchPayload(data) {
  const items = Array.isArray(data) ? data : Array.isArray(data.results) ? data.results : [];
  return items.map((item, index) => `${index + 1}. ${item.title || 'Untitled'}\n${item.url || ''}\n${item.snippet || item.content || ''}`).join('\n\n');
}

function showSources(sources) {
  state.latestSources = Array.isArray(sources) ? sources : [];
  if (!state.latestSources.length) {
    el.sourceList.innerHTML = '';
    el.sourcePanel.classList.add('hidden');
    return;
  }

  el.sourceList.innerHTML = '';
  state.latestSources.forEach((source) => {
    const card = document.createElement('div');
    card.className = 'resource-card';
    card.innerHTML = `
      <strong>${escapeHtml(source.title || 'Source')}</strong>
      <p class="muted">${escapeHtml(source.snippet || source.content || '')}</p>
      <a href="${escapeAttr(source.url || '#')}" target="_blank" rel="noreferrer">Open source</a>
    `;
    el.sourceList.appendChild(card);
  });
  el.sourcePanel.classList.remove('hidden');
}

function renderStudyTags() {
  el.studyTags.innerHTML = ['NCERT', 'Official portals', 'PYQs', 'Revision sheets', 'Topic maps', 'Your own notes']
    .map((tag) => `<span class="study-tag">${tag}</span>`)
    .join('');
}

async function refreshResourcesFromBackend() {
  try {
    const response = await fetch(`${normalizeBaseUrl(state.settings.backendUrl)}/api/resources`);
    if (!response.ok) return;
    const data = await response.json();
    if (data?.resources && typeof data.resources === 'object') {
      const localCustom = safeJSON('astrax_resources', DEFAULT_RESOURCES);
      state.resources = mergeResourceMaps(data.resources, localCustom);
      localStorage.setItem('astrax_resources', JSON.stringify(state.resources));
    }
  } catch {
    // keep local data
  }
}

function mergeResourceMaps(baseMap, extraMap) {
  const merged = {};
  const exams = new Set([...Object.keys(baseMap || {}), ...Object.keys(extraMap || {})]);
  exams.forEach((exam) => {
    const items = [...(baseMap?.[exam] || []), ...(extraMap?.[exam] || [])];
    merged[exam] = dedupeBy(items, (item) => `${item.title}|${item.link}`);
  });
  return merged;
}

function renderResources() {
  el.resourceList.innerHTML = '';
  Object.entries(state.resources).forEach(([exam, items]) => {
    const section = document.createElement('div');
    section.className = 'resource-card';
    section.innerHTML = `<strong>${escapeHtml(exam)}</strong>`;
    const list = document.createElement('div');
    list.style.marginTop = '10px';
    items.forEach((item) => {
      const row = document.createElement('div');
      row.style.marginBottom = '10px';
      row.innerHTML = `${escapeHtml(item.title)}<br />${item.link ? `<a href="${escapeAttr(item.link)}" target="_blank" rel="noreferrer">Open</a>` : 'No link'}`;
      list.appendChild(row);
    });
    section.appendChild(list);
    el.resourceList.appendChild(section);
  });
}

function addResource() {
  const exam = el.examSelect.value;
  const title = el.resourceTitle.value.trim();
  const link = el.resourceLink.value.trim();
  if (!title) return;
  state.resources[exam] = state.resources[exam] || [];
  state.resources[exam].unshift({ title, link });
  state.resources[exam] = dedupeBy(state.resources[exam], (item) => `${item.title}|${item.link}`);
  localStorage.setItem('astrax_resources', JSON.stringify(state.resources));
  el.resourceTitle.value = '';
  el.resourceLink.value = '';
  renderResources();
}

async function refreshOpportunitiesFromBackend(forceRefresh) {
  const base = normalizeBaseUrl(state.settings.backendUrl);
  try {
    if (forceRefresh) {
      const refreshResponse = await fetch(`${base}/api/opportunities-refresh`, { method: 'POST' });
      if (!refreshResponse.ok) throw new Error('refresh_not_available');
    }
  } catch {
    // ignore and fall back to GET
  }

  try {
    const response = await fetch(`${base}/api/opportunities`);
    if (!response.ok) return;
    const data = await response.json();
    if (Array.isArray(data?.items)) {
      const localCustom = safeJSON('astrax_opportunities', DEFAULT_OPPORTUNITIES);
      state.opportunities = dedupeBy([...data.items, ...localCustom], (item) => `${item.title}|${item.link}`);
      localStorage.setItem('astrax_opportunities', JSON.stringify(state.opportunities));
      el.opportunityMeta.textContent = data.generatedAt ? `Updated ${new Date(data.generatedAt).toLocaleString()}` : 'Curated feed';
    }
  } catch {
    el.opportunityMeta.textContent = 'Offline feed';
  }
}

function renderOpportunities() {
  el.opportunityList.innerHTML = '';
  state.opportunities.forEach((item) => {
    const card = document.createElement('div');
    card.className = 'resource-card';
    card.innerHTML = `
      <strong>${escapeHtml(item.title)}</strong>
      <p class="muted">${escapeHtml(item.category || 'Opportunity')} • ${escapeHtml(item.source || 'Official')} • ${escapeHtml(item.date || '')}</p>
      <a href="${escapeAttr(item.link)}" target="_blank" rel="noreferrer">Official link</a>
    `;
    el.opportunityList.appendChild(card);
  });
}

function addOpportunity() {
  const title = el.opportunityTitle.value.trim();
  const link = el.opportunityLink.value.trim();
  if (!title || !link) return;
  state.opportunities.unshift({ title, link, source: 'Custom', category: 'Opportunity', date: new Date().toLocaleDateString() });
  state.opportunities = dedupeBy(state.opportunities, (item) => `${item.title}|${item.link}`);
  localStorage.setItem('astrax_opportunities', JSON.stringify(state.opportunities));
  el.opportunityTitle.value = '';
  el.opportunityLink.value = '';
  renderOpportunities();
}

function generateStarterApp() {
  const idea = el.appIdeaInput.value.trim() || 'Create a futuristic student app with dashboards, cards, and contact actions.';
  const lower = idea.toLowerCase();
  const mode = lower.includes('portfolio') ? 'Portfolio' : lower.includes('shop') || lower.includes('ecommerce') ? 'Storefront' : lower.includes('blog') ? 'Blog' : lower.includes('dashboard') || lower.includes('admin') ? 'Dashboard' : 'Landing App';
  const accent = lower.includes('purple') ? '#a78bfa' : lower.includes('green') ? '#34d399' : lower.includes('red') ? '#fb7185' : '#63d4ff';
  const themeBg = lower.includes('light') ? '#f7fbff' : '#07111f';
  const text = lower.includes('light') ? '#07111f' : '#eef8ff';
  const card = lower.includes('light') ? '#ffffff' : 'rgba(255,255,255,0.06)';

  state.generatedAppHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${mode}</title>
  <style>
    :root { --accent: ${accent}; --bg: ${themeBg}; --text: ${text}; --card: ${card}; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Inter, system-ui, sans-serif; background: radial-gradient(circle at top right, rgba(99,212,255,0.18), transparent 30%), var(--bg); color: var(--text); }
    .wrap { width: min(1100px, calc(100vw - 32px)); margin: 0 auto; padding: 28px 0 54px; }
    .hero, .card { border-radius: 22px; border: 1px solid rgba(99,212,255,0.18); background: var(--card); backdrop-filter: blur(18px); }
    .hero { padding: 34px; margin-bottom: 18px; }
    .badge { display: inline-block; padding: 8px 12px; border-radius: 999px; background: rgba(99,212,255,0.14); color: var(--accent); font-size: 12px; letter-spacing: .12em; text-transform: uppercase; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px; }
    .card { padding: 22px; }
    .btn { display: inline-block; text-decoration: none; background: linear-gradient(135deg, var(--accent), #d9f8ff); color: #07111f; padding: 12px 18px; border-radius: 14px; font-weight: 700; margin-top: 12px; }
    p { color: ${lower.includes('light') ? '#2c445a' : '#b2c6d8'}; line-height: 1.7; }
  </style>
</head>
<body>
  <div class="wrap">
    <section class="hero">
      <span class="badge">${mode}</span>
      <h1>${escapeHtmlForTemplate(titleCaseFromIdea(idea))}</h1>
      <p>${escapeHtmlForTemplate(idea)}</p>
      <a class="btn" href="#features">Explore</a>
    </section>
    <section id="features" class="grid">
      <article class="card"><h3>Hero Story</h3><p>Use this area for your main promise, founder story, or student mission statement.</p></article>
      <article class="card"><h3>Feature Cards</h3><p>Add benefits, pricing, courses, projects, or dashboards based on your needs.</p></article>
      <article class="card"><h3>Community / Contact</h3><p>Add WhatsApp, Telegram, email, or lead capture CTA here.</p></article>
      <article class="card"><h3>Growth Section</h3><p>Show testimonials, stats, scholarship updates, or calls to action.</p></article>
    </section>
  </div>
</body>
</html>`;

  el.generatedAppPreview.textContent = state.generatedAppHtml;
}

function titleCaseFromIdea(text) {
  return text.replace(/\s+/g, ' ').trim().split(' ').slice(0, 12).map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
}

async function copyGeneratedApp() {
  if (!state.generatedAppHtml) generateStarterApp();
  try {
    await navigator.clipboard.writeText(state.generatedAppHtml);
    addMessage('assistant', 'Generated app code copied to clipboard.');
  } catch {
    addMessage('assistant', 'Clipboard copy failed. You can still download the HTML file.');
  }
}

function downloadGeneratedApp() {
  if (!state.generatedAppHtml) generateStarterApp();
  const blob = new Blob([state.generatedAppHtml], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'astrax-generated-app.html';
  link.click();
  URL.revokeObjectURL(url);
}

function drawCanvasPlaceholder() {
  const canvas = el.imageCanvas;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  gradient.addColorStop(0, '#07111f');
  gradient.addColorStop(1, '#123055');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#9ce7ff';
  ctx.font = '700 26px system-ui';
  ctx.fillText('AstraX Image Studio', 30, 60);
  ctx.font = '16px system-ui';
  ctx.fillStyle = '#d7ecff';
  ctx.fillText('Upload an image to start editing locally.', 30, 96);
  ctx.fillText('Try prompt styles: cinematic, warm, bright, vintage, dramatic.', 30, 124);
}

function handleImageUpload(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      state.currentImage = img;
      fitCanvasToImage(img);
      redrawCanvas();
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

function fitCanvasToImage(img) {
  const canvas = el.imageCanvas;
  const maxWidth = 960;
  const ratio = img.width / img.height;
  canvas.width = Math.min(maxWidth, img.width);
  canvas.height = Math.round(canvas.width / ratio);
}

function applyPromptStyle() {
  const prompt = el.imagePrompt.value.toLowerCase();
  let brightness = 100;
  let contrast = 100;
  let saturation = 100;
  state.imageExtras = { sepia: 0, hue: 0, blur: 0 };

  if (prompt.includes('bright')) brightness = 118;
  if (prompt.includes('warm')) { brightness = 108; saturation = 118; state.imageExtras.hue = -8; }
  if (prompt.includes('vintage')) { brightness = 104; saturation = 88; state.imageExtras.sepia = 28; }
  if (prompt.includes('dramatic')) contrast = 132;
  if (prompt.includes('cinematic')) { brightness = 94; contrast = 118; saturation = 112; }
  if (prompt.includes('cool')) state.imageExtras.hue = 12;
  if (prompt.includes('soft')) state.imageExtras.blur = 0.4;

  el.brightnessSlider.value = brightness;
  el.contrastSlider.value = contrast;
  el.saturationSlider.value = saturation;
  redrawCanvas();
}

function redrawCanvas() {
  const canvas = el.imageCanvas;
  const ctx = canvas.getContext('2d');
  if (!state.currentImage) return drawCanvasPlaceholder();
  const brightness = Number(el.brightnessSlider.value);
  const contrast = Number(el.contrastSlider.value);
  const saturation = Number(el.saturationSlider.value);
  const { sepia, hue, blur } = state.imageExtras;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) sepia(${sepia}%) hue-rotate(${hue}deg) blur(${blur}px)`;
  ctx.drawImage(state.currentImage, 0, 0, canvas.width, canvas.height);
  ctx.filter = 'none';
}

function downloadCanvasImage() {
  const url = el.imageCanvas.toDataURL('image/png');
  const link = document.createElement('a');
  link.href = url;
  link.download = 'astrax-edited-image.png';
  link.click();
}

function generatePinterestCopy() {
  const topic = el.pinTopic.value.trim() || 'AI-powered student growth';
  const audience = el.pinAudience.value.trim() || 'students and creators';
  const vibe = el.pinVibe.value.trim() || 'clean futuristic';
  const cta = el.pinCTA.value.trim() || 'save this for later';
  const title = `${topic} ideas for ${audience}`;
  const description = `Level up with ${topic}. Designed for ${audience}, this ${vibe} concept blends clarity, utility, and scroll-stopping appeal. ${cta}.`;
  const hashtags = [topic, audience, vibe, 'PinterestTips', 'AestheticDesign', 'IndiaCreators']
    .flatMap((item) => item.split(/\s+/))
    .filter(Boolean)
    .slice(0, 12)
    .map((item) => `#${item.replace(/[^a-z0-9]/gi, '')}`)
    .join(' ');
  el.pinResult.textContent = `Title: ${title}\n\nDescription: ${description}\n\nHashtags: ${hashtags}`;
}

function renderVoiceGrid() {
  el.voiceGrid.innerHTML = '';
  VOICE_PRESETS.forEach((preset) => {
    const card = document.createElement('div');
    card.className = 'voice-card';
    card.innerHTML = `
      <strong>${escapeHtml(preset.name)}</strong>
      <div class="voice-meta"><span>${escapeHtml(preset.type)}</span><span>${escapeHtml(preset.region)}</span></div>
      <p class="muted">${escapeHtml(preset.tone)}</p>
      <button class="ghost-btn small-btn">Preview Voice</button>
    `;
    card.querySelector('button').addEventListener('click', () => previewVoice(preset));
    el.voiceGrid.appendChild(card);
  });
}

function previewVoice(preset) {
  if (!('speechSynthesis' in window)) {
    addMessage('assistant', 'Speech synthesis preview is not supported in this browser.');
    return;
  }
  const utterance = new SpeechSynthesisUtterance(`Hello, I am ${preset.name}, your ${preset.tone} voice preset for AstraX Bharat AI.`);
  const voices = window.speechSynthesis.getVoices();
  const bestVoice = findBestVoice(voices, state.language);
  if (bestVoice) utterance.voice = bestVoice;
  utterance.lang = state.language === 'hinglish' ? 'en-IN' : state.language;
  utterance.rate = 1;
  utterance.pitch = preset.type === 'Girl' ? 1.08 : 0.96;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
}

function setupSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    el.voiceStatus.textContent = 'Voice input is not supported in this browser preview.';
    return;
  }

  recognition = new SpeechRecognition();
  recognition.lang = state.language === 'hinglish' ? 'hi-IN' : state.language;
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => { el.voiceStatus.textContent = 'Listening... बोलिए'; el.voiceInputBtn.textContent = 'Stop Listening'; };
  recognition.onresult = (event) => {
    const transcript = event.results?.[0]?.[0]?.transcript || '';
    el.promptInput.value = transcript;
    el.voiceStatus.textContent = 'Voice captured. You can edit text and send.';
  };
  recognition.onerror = () => { el.voiceStatus.textContent = 'Voice recognition failed. Try again or type manually.'; el.voiceInputBtn.textContent = 'Voice Input'; };
  recognition.onend = () => { el.voiceInputBtn.textContent = 'Voice Input'; };
}

function toggleSpeechRecognition() {
  if (!recognition) {
    addMessage('assistant', 'Voice input is not supported in this browser.');
    return;
  }
  try {
    recognition.lang = state.language === 'hinglish' ? 'hi-IN' : state.language;
    recognition.start();
  } catch {
    recognition.stop();
  }
}

function findBestVoice(voices, langCode) {
  if (!Array.isArray(voices) || !voices.length) return null;
  const normalized = langCode === 'hinglish' ? 'en-IN' : langCode;
  return voices.find((voice) => voice.lang === normalized) || voices.find((voice) => voice.lang.startsWith(normalized.split('-')[0])) || voices.find((voice) => /india|hindi|english india/i.test(`${voice.name} ${voice.lang}`)) || voices[0];
}

function runQuickAction(action) {
  const actions = {
    whatsapp: () => openExternal('https://wa.me/'),
    mail: () => openExternal('mailto:'),
    call: () => openExternal('tel:'),
    maps: () => openExternal('https://maps.google.com/'),
    youtube: () => openExternal('https://www.youtube.com/'),
    camera: () => el.cameraInput.click(),
    calendar: () => openExternal('https://calendar.google.com/'),
    playstore: () => openExternal('https://play.google.com/store')
  };
  actions[action]?.();
}

function openExternal(url) {
  window.open(url, '_blank', 'noopener,noreferrer');
}

function generateQr() {
  const url = el.deployUrl.value.trim();
  if (!url) return;
  if (url === PUBLIC_APP_URL) {
    el.qrImage.src = PUBLIC_QR_IMAGE;
  } else {
    el.qrImage.src = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(url)}`;
  }
  el.qrImage.alt = `QR code for ${url}`;
  el.publishGuide.textContent = `Deploy URL ready: ${url}\n\nOpen it on mobile and use Install / Add to Home Screen. For APK wrapping, use capacitor.config.json and docs/ANDROID.md.`;
}

function autoFillQrWithCurrentUrl() {
  const currentUrl = location.protocol.startsWith('http') ? location.href : '';
  const isLocalHost = /localhost|127\.0\.0\.1|0\.0\.0\.0/i.test(location.hostname || '');
  const chosenUrl = currentUrl && !isLocalHost ? currentUrl : PUBLIC_APP_URL;
  el.deployUrl.value = chosenUrl;
  el.qrImage.src = PUBLIC_QR_IMAGE;
  el.qrImage.alt = `QR code for ${chosenUrl}`;
  el.publishGuide.textContent = `Permanent public app URL: ${PUBLIC_APP_URL}\n\nUse this QR for Android install/share. If you change your deployment URL later, generate a new QR from this panel.`;
}

function downloadDeployGuide() {
  const content = `AstraX Bharat AI Deploy Guide\n\n1. Run locally: npm start\n2. Add env vars from .env.example\n3. Deploy Node app to Render/Railway/Fly.io/VPS\n4. Add Firebase config in app settings if using auth\n5. Open deployed URL on mobile and use Install / Add to Home Screen\n6. For APK wrapping, follow docs/ANDROID.md\n\nImportant: Real search, voice, and image AI need your own provider keys. Pirated notes and mod APK features are not included.`;
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'astrax-deploy-guide.txt';
  link.click();
  URL.revokeObjectURL(url);
}

async function saveSettings() {
  state.settings = {
    backendUrl: el.backendUrl.value.trim(),
    useBackendProxy: el.useBackendProxy.checked,
    aiBaseUrl: el.aiBaseUrl.value.trim() || DEFAULT_SETTINGS.aiBaseUrl,
    aiModel: el.aiModel.value.trim() || DEFAULT_SETTINGS.aiModel,
    aiApiKey: el.aiApiKey.value.trim(),
    searchEndpoint: el.searchEndpoint.value.trim(),
    searchApiKey: el.searchApiKey.value.trim(),
    imageEndpoint: el.imageEndpoint.value.trim(),
    ttsEndpoint: el.ttsEndpoint.value.trim(),
    firebaseApiKey: el.firebaseApiKey.value.trim(),
    firebaseAuthDomain: el.firebaseAuthDomain.value.trim(),
    firebaseProjectId: el.firebaseProjectId.value.trim(),
    firebaseAppId: el.firebaseAppId.value.trim(),
    firebaseStorageBucket: el.firebaseStorageBucket.value.trim(),
    firebaseMessagingSenderId: el.firebaseMessagingSenderId.value.trim(),
    notes: el.settingsNotes.value.trim()
  };

  localStorage.setItem('astrax_settings', JSON.stringify(state.settings));
  el.settingsDrawer.classList.add('hidden');
  await maybeInitFirebase(true);
  addMessage('assistant', 'Settings saved locally. For production, keep keys on the backend and Firebase auth config in allowed domains.');
}

function loadSettingsIntoForm() {
  el.backendUrl.value = state.settings.backendUrl || '';
  el.useBackendProxy.checked = state.settings.useBackendProxy !== false;
  el.aiBaseUrl.value = state.settings.aiBaseUrl || DEFAULT_SETTINGS.aiBaseUrl;
  el.aiModel.value = state.settings.aiModel || DEFAULT_SETTINGS.aiModel;
  el.aiApiKey.value = state.settings.aiApiKey || '';
  el.searchEndpoint.value = state.settings.searchEndpoint || '';
  el.searchApiKey.value = state.settings.searchApiKey || '';
  el.imageEndpoint.value = state.settings.imageEndpoint || '';
  el.ttsEndpoint.value = state.settings.ttsEndpoint || '';
  el.firebaseApiKey.value = state.settings.firebaseApiKey || '';
  el.firebaseAuthDomain.value = state.settings.firebaseAuthDomain || '';
  el.firebaseProjectId.value = state.settings.firebaseProjectId || '';
  el.firebaseAppId.value = state.settings.firebaseAppId || '';
  el.firebaseStorageBucket.value = state.settings.firebaseStorageBucket || '';
  el.firebaseMessagingSenderId.value = state.settings.firebaseMessagingSenderId || '';
  el.settingsNotes.value = state.settings.notes || '';
}

function resetSettings() {
  state.settings = { ...DEFAULT_SETTINGS };
  localStorage.setItem('astrax_settings', JSON.stringify(state.settings));
  loadSettingsIntoForm();
  firebaseState.initialized = false;
  firebaseState.user = null;
  updateFirebaseStatus('Firebase config reset. Add your project values in Settings to enable login/signup.');
  updateAuthUi();
}

async function maybeInitFirebase(force = false) {
  const config = getFirebaseConfig();
  const configKey = JSON.stringify(config);
  if (!isFirebaseConfigured(config)) {
    updateFirebaseStatus('Firebase not configured yet. Add Firebase values in Settings to enable login, signup, and cloud sync.');
    firebaseState.initialized = false;
    return;
  }

  if (firebaseState.initializing) return;
  if (!force && firebaseState.initialized && firebaseState.configKey === configKey) return;

  firebaseState.initializing = true;
  updateFirebaseStatus('Initializing Firebase...');

  try {
    const [appModule, authModule, firestoreModule] = await Promise.all([
      import('https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js'),
      import('https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js'),
      import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js')
    ]);

    const appName = `astrax-${config.projectId}`;
    const existing = appModule.getApps().find((item) => item.name === appName);
    const app = existing || appModule.initializeApp(config, appName);
    const auth = authModule.getAuth(app);
    const db = firestoreModule.getFirestore(app);

    firebaseState.app = app;
    firebaseState.auth = auth;
    firebaseState.db = db;
    firebaseState.modules = { authModule, firestoreModule };
    firebaseState.initialized = true;
    firebaseState.configKey = configKey;
    updateFirebaseStatus('Firebase ready. Auth and Firestore hooks are enabled.');

    authModule.onAuthStateChanged(auth, async (user) => {
      firebaseState.user = user || null;
      updateAuthUi();
      if (user) await syncUserProfile();
    });
  } catch (error) {
    firebaseState.initialized = false;
    updateFirebaseStatus(`Firebase init failed in this preview. After deployment, check config/domains. Error: ${error.message}`);
  } finally {
    firebaseState.initializing = false;
  }
}

function getFirebaseConfig() {
  return {
    apiKey: state.settings.firebaseApiKey,
    authDomain: state.settings.firebaseAuthDomain,
    projectId: state.settings.firebaseProjectId,
    appId: state.settings.firebaseAppId,
    storageBucket: state.settings.firebaseStorageBucket || undefined,
    messagingSenderId: state.settings.firebaseMessagingSenderId || undefined
  };
}

function isFirebaseConfigured(config) {
  return Boolean(config.apiKey && config.authDomain && config.projectId && config.appId);
}

function updateFirebaseStatus(message) {
  if (el.firebaseStatus) el.firebaseStatus.textContent = message;
}

function openAuthDrawer() {
  el.authDrawer.classList.remove('hidden');
}

function closeAuthDrawer() {
  el.authDrawer.classList.add('hidden');
}

function updateAuthUi() {
  const user = firebaseState.user;
  if (user) {
    el.authStatus.textContent = user.displayName ? `Hi, ${user.displayName}` : user.email || 'Logged in';
    el.authBtn.textContent = 'Account';
    return;
  }
  el.authStatus.textContent = firebaseState.initialized ? 'Firebase Ready' : 'Guest Mode';
  el.authBtn.textContent = firebaseState.initialized ? 'Login / Signup' : 'Setup Auth';
}

async function handleSignup() {
  await maybeInitFirebase();
  if (!firebaseState.initialized) {
    addMessage('assistant', 'Firebase is not ready yet. Add Firebase config in Settings and deploy the app.');
    return;
  }

  const name = el.authName.value.trim();
  const email = el.authEmail.value.trim();
  const password = el.authPassword.value.trim();
  const role = el.authRole.value.trim();
  if (!email || !password) return;

  try {
    const { authModule } = firebaseState.modules;
    const result = await authModule.createUserWithEmailAndPassword(firebaseState.auth, email, password);
    if (name) await authModule.updateProfile(result.user, { displayName: name });
    firebaseState.user = authModule.getAuth(firebaseState.app).currentUser;
    await syncUserProfile({ role, name: name || result.user.displayName || '' });
    updateAuthUi();
    addMessage('assistant', 'Account created successfully.');
    closeAuthDrawer();
  } catch (error) {
    addMessage('assistant', `Signup failed: ${error.message}`);
  }
}

async function handleLogin() {
  await maybeInitFirebase();
  if (!firebaseState.initialized) {
    addMessage('assistant', 'Firebase is not ready yet. Add Firebase config in Settings and deploy the app.');
    return;
  }

  const email = el.authEmail.value.trim();
  const password = el.authPassword.value.trim();
  if (!email || !password) return;

  try {
    const { authModule } = firebaseState.modules;
    await authModule.signInWithEmailAndPassword(firebaseState.auth, email, password);
    addMessage('assistant', 'Logged in successfully.');
    closeAuthDrawer();
  } catch (error) {
    addMessage('assistant', `Login failed: ${error.message}`);
  }
}

async function handleLogout() {
  if (!firebaseState.initialized || !firebaseState.auth) {
    addMessage('assistant', 'No Firebase session is active.');
    return;
  }
  try {
    const { authModule } = firebaseState.modules;
    await authModule.signOut(firebaseState.auth);
    firebaseState.user = null;
    updateAuthUi();
    addMessage('assistant', 'Logged out successfully.');
  } catch (error) {
    addMessage('assistant', `Logout failed: ${error.message}`);
  }
}

async function syncUserProfile(extra = {}) {
  if (!firebaseState.user || !firebaseState.db || !firebaseState.modules) return;
  try {
    const { firestoreModule } = firebaseState.modules;
    await firestoreModule.setDoc(
      firestoreModule.doc(firebaseState.db, 'users', firebaseState.user.uid),
      {
        uid: firebaseState.user.uid,
        email: firebaseState.user.email || '',
        name: extra.name || firebaseState.user.displayName || '',
        role: extra.role || el.authRole.value.trim() || 'User',
        updatedAt: firestoreModule.serverTimestamp()
      },
      { merge: true }
    );
  } catch {
    // silent
  }
}

async function persistChatSnippet(role, text) {
  if (!firebaseState.user || !firebaseState.db || !firebaseState.modules) return;
  try {
    const { firestoreModule } = firebaseState.modules;
    await firestoreModule.addDoc(
      firestoreModule.collection(firebaseState.db, 'users', firebaseState.user.uid, 'chatSnippets'),
      {
        role,
        text: String(text).slice(0, 2000),
        language: state.language,
        mode: state.mode,
        createdAt: firestoreModule.serverTimestamp()
      }
    );
  } catch {
    // silent
  }
}

async function installPwa() {
  if (!state.installPromptEvent) {
    addMessage('assistant', 'Install prompt not available yet. Open this on HTTPS and use browser Install / Add to Home Screen if needed.');
    return;
  }
  state.installPromptEvent.prompt();
  await state.installPromptEvent.userChoice;
  state.installPromptEvent = null;
  el.installBtn.textContent = 'Install App';
}

async function shareApp() {
  const url = el.deployUrl.value.trim() || location.href;
  if (navigator.share) {
    try {
      await navigator.share({ title: 'AstraX Bharat AI', text: 'Open my AI assistant app', url });
      return;
    } catch {}
  }
  try {
    await navigator.clipboard.writeText(url);
    addMessage('assistant', `Share link copied: ${url}`);
  } catch {
    addMessage('assistant', `Share this URL manually: ${url}`);
  }
}

function registerServiceWorker() {
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
}

function normalizeChatEndpoint(baseUrl) {
  if (baseUrl.includes('/chat/completions')) return baseUrl;
  return `${baseUrl.replace(/\/$/, '')}/chat/completions`;
}

function normalizeBaseUrl(baseUrl) {
  return baseUrl ? baseUrl.replace(/\/$/, '') : '';
}

function safeJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function dedupeBy(list, keyFn) {
  const seen = new Set();
  return list.filter((item) => {
    const key = keyFn(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function escapeHtml(text) {
  return String(text).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}

function escapeAttr(text) {
  return escapeHtml(text);
}

function escapeHtmlForTemplate(text) {
  return String(text).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}
